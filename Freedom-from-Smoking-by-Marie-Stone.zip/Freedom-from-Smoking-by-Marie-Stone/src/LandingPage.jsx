import React from "react";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-200 to-emerald-100 text-slate-800">
      <header className="min-h-[60vh] flex items-center">
        <div className="max-w-4xl mx-auto text-center px-6 py-20">
          <h1 className="text-4xl md:text-5xl font-extrabold leading-tight text-slate-900">Freedom from Smoking</h1>
          <p className="mt-2 text-lg text-slate-700">Quit Smoking for Good in 9 Weeks</p>
          <p className="mt-6 text-md md:text-lg text-slate-700">
            Take your first step toward a healthy, smoke-free life.
            Join Marie Stone’s 9-week journey to freedom from smoking — one breath at a time.
          </p>
          <div className="mt-8">
            <a href="mailto:theartofrespect@gmail.com" className="inline-block bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-3 rounded-md">Buy the eBook (Coming Soon)</a>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-12">
        <section id="about" className="bg-white bg-opacity-60 p-6 rounded-lg shadow-sm">
          <h2 className="text-2xl font-semibold">About Marie</h2>
          <p className="mt-3 text-slate-700">Hi, I’m Marie Stone. After my own journey to quit smoking, I created this 9-week program to help others find their freedom, regain their health, and rediscover peace of mind — one breath at a time.</p>
        </section>

        <section id="contact" className="mt-8 text-sm text-slate-600">
          <p>Contact Marie: <a href="mailto:theartofrespect@gmail.com" className="underline">theartofrespect@gmail.com</a></p>
        </section>
      </main>

      <footer className="mt-12 py-6 text-center text-sm text-slate-600">
        © 2025 Marie Stone. All rights reserved.
      </footer>
    </div>
  );
}
